const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

const Product = require('./models/product');

app.get('/products', async (req, res) => {
    const products = await Product.getAll();
    res.json(products);
});

app.get('/products/:id', async (req, res) => {
    const product = await Product.getById(req.params.id);
    if (!product) return res.status(404).send('Данный продукт не найден');
    res.json(product);
});

app.post('/products', async (req, res) => {
    const newProduct = await Product.add(req.body.name, req.body.price);
    res.status(201).json({ id: newProduct, name: req.body.name, price: req.body.price });
});

app.put('/products/:id', async (req, res) => {
    const updated = await Product.update(req.params.id, req.body.name, req.body.price);
    if (updated === 0) return res.status(404).send('Данный продукт не найден');
    res.json({ id: req.params.id, name: req.body.name, price: req.body.price });
});

app.delete('/products/:id', async (req, res) => {
    const deleted = await Product.delete(req.params.id);
    if (deleted === 0) return res.status(404).send('Данный продукт не найден');
    res.status(204).send();
});

app.listen(port, () => {
    console.log(`Сервер запущен на порту: ${port}`);
});